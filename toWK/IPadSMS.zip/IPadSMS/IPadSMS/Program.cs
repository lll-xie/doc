﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace IPadSMS
{
    class Program
    {
        static void Main(string[] args)
        {
            string ScheduleTask = ConfigHelper.GetAppConfig("ScheduleTask");
            string MsgFrom = ConfigHelper.GetAppConfig("MsgType");

            //your IPAD DB connection string 
            var SMSdatasource = ConfigHelper.GetAppConfig("SMSServerIP");//your IPAD server
            var SMSDB = ConfigHelper.GetAppConfig("SMSDataBase"); //your IPAD database name
            var SMSuser = ConfigHelper.GetAppConfig("SMSUser"); //username of IPAD server to connect
            var SMSPWD = ConfigHelper.GetAppConfig("SMSPassword"); //IPAD password

            string SMSconnString = @"Data Source=" + SMSdatasource + ";Initial Catalog="
                        + SMSDB + ";Persist Security Info=True;User ID=" + SMSuser + ";Password=" + SMSPWD;

            //your SMS DB connection string 

            var IPADdatasource = ConfigHelper.GetAppConfig("IPadDBIP");//your SMS server
            var IPADDB = ConfigHelper.GetAppConfig("IPADDBName"); //your SMS database name
            var IPADuser = ConfigHelper.GetAppConfig("IPADDBUser"); //username of SMS server to connect
            var IPADPWD = ConfigHelper.GetAppConfig("IPADDBPassword"); //SMS password
            string IPADconnString = @"server=" + IPADdatasource + ";database=" + IPADDB + "; userid=" + IPADuser + "; password=" + IPADPWD + ";CharSet=utf8;pooling=true;SslMode = none";

            SqlConnection SMSconn = new SqlConnection(SMSconnString);
            SMSconn.Open();

            MySqlConnection IPADconn = new MySqlConnection(IPADconnString);
            IPADconn.Open();

            // Get the SMS snd list, for administrators
            Console.WriteLine("Get the Sending List!");
            MySqlCommand SMSListcmd = new MySqlCommand("Select Name, Phone from smsstaff where Send = 1;", IPADconn);

            MySqlDataReader dtrSMSList = SMSListcmd.ExecuteReader();
            DataTable dtSMSList = new DataTable();
            dtSMSList.Load(dtrSMSList);
            string SMSPhoneList = "";
            if (dtSMSList.Rows.Count > 0)
            {
                foreach (DataRow row in dtSMSList.Rows)
                {
                    if (SMSPhoneList.Length == 0)
                    {
                        SMSPhoneList = row[1].ToString();
                    }
                    else
                    {
                        SMSPhoneList = SMSPhoneList + "," + row[1].ToString();
                    }
                }
            }

            //Get the iPad which borrow over 12 hours and no return.
            //Console.WriteLine("Send 12 hours SMS!");
            MySqlCommand IPADcmd = new MySqlCommand("Select p_name, p_borrower,TIMESTAMPDIFF(HOUR, p_b_time, now()) b_hour from t_Padinfo where IFNULL(p_borrower, '') <> '' And (TIMESTAMPDIFF(HOUR, p_b_time, now())>=12 And TIMESTAMPDIFF(HOUR, p_b_time, now()) < 24);", IPADconn);

            MySqlDataReader dtrIPAD12 = IPADcmd.ExecuteReader();
            DataTable dtIPAD12 = new DataTable();
            dtIPAD12.Load(dtrIPAD12);
            if (dtIPAD12.Rows.Count > 0)
            {
                foreach (DataRow row in dtIPAD12.Rows)
                {
                    string PadName = row[0].ToString();
                    string PadUSer = row[1].ToString();
                    string padHour = row[2].ToString();

                    // Get the SMS Phone
                    MySqlCommand GetPhonecmd = new MySqlCommand("SELECT p_name, p_phone FROM t_person where p_id = @id;", IPADconn);
                    GetPhonecmd.Parameters.AddWithValue("@id", PadUSer);

                    MySqlDataReader dtrPhone = GetPhonecmd.ExecuteReader();
                    DataTable dtPhone = new DataTable();
                    dtPhone.Load(dtrPhone);
                    string Phone = "";
                    string b_User = "";
                    if (dtPhone.Rows.Count > 0)
                    {
                        foreach (DataRow rowP in dtPhone.Rows)
                        {
                            b_User = rowP[0].ToString();
                            Phone = SMSPhoneList + "," + rowP[1].ToString();
                        }
                    }
                    string Message = "[Testing...](" + b_User + ")借PAD超过12小时未归还，请尽速归还，并登记说明原因。";
                    SqlCommand SMScmd = new SqlCommand("INSERT INTO [dbo].[MsgSend] ([MsgFrom], [Phone], [MsgTime], [MsgType], [Message]) VALUES (@MsgFrom, @Phone, @MsgTime, @MsgType, @Message)", SMSconn);
                    SMScmd.Parameters.AddWithValue("@MsgFrom", MsgFrom);
                    SMScmd.Parameters.AddWithValue("@Phone", Phone);
                    SMScmd.Parameters.AddWithValue("@MsgTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    SMScmd.Parameters.AddWithValue("@MsgType", 1.ToString());
                    SMScmd.Parameters.AddWithValue("@Message", Message);
                    try
                    {
                        SMScmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString(), "Error for 12 hour");
                    }
                }
            }

            //Get the iPad which borrow over 24 hours and no return.
            //Console.WriteLine("Send 24 hours SMS!");
            IPADcmd = new MySqlCommand("Select p_name, p_borrower,TIMESTAMPDIFF(HOUR, p_b_time, now()) b_hour from t_Padinfo where IFNULL(p_borrower, '') <> '' And (TIMESTAMPDIFF(HOUR, p_b_time, now())>=24 And TIMESTAMPDIFF(HOUR, p_b_time, now()) < 36); ", IPADconn);

            MySqlDataReader dtrIPAD24 = IPADcmd.ExecuteReader();
            DataTable dtIPAD24 = new DataTable();
            dtIPAD24.Load(dtrIPAD24);
            if (dtIPAD24.Rows.Count > 0)
            {
                foreach (DataRow row in dtIPAD24.Rows)
                {
                    string PadName = row[0].ToString();
                    string PadUSer = row[1].ToString();
                    string padHour = row[2].ToString();

                    // Get the SMS Phone
                    MySqlCommand GetPhonecmd = new MySqlCommand("SELECT p_name, p_phone FROM t_person where p_id = @id;", IPADconn);
                    GetPhonecmd.Parameters.AddWithValue("@id", PadUSer);

                    MySqlDataReader dtrPhone = GetPhonecmd.ExecuteReader();
                    DataTable dtPhone = new DataTable();
                    dtPhone.Load(dtrPhone);
                    string Phone = "";
                    string b_User = "";
                    if (dtPhone.Rows.Count > 0)
                    {
                        foreach (DataRow rowP in dtPhone.Rows)
                        {
                            b_User = rowP[0].ToString();
                            Phone = SMSPhoneList + "," + rowP[1].ToString();
                        }
                    }
                    string Message = "[Testing...](" + b_User + ")借PAD超过24小时未归还，请尽速归还，并查明原因。";
                    SqlCommand SMScmd = new SqlCommand("INSERT INTO [dbo].[MsgSend] ([MsgFrom], [Phone], [MsgTime], [MsgType], [Message]) VALUES (@MsgFrom, @Phone, @MsgTime, @MsgType, @Message)", SMSconn);
                    SMScmd.Parameters.AddWithValue("@MsgFrom", MsgFrom);
                    SMScmd.Parameters.AddWithValue("@Phone", Phone);
                    SMScmd.Parameters.AddWithValue("@MsgTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    SMScmd.Parameters.AddWithValue("@MsgType", 1.ToString());
                    SMScmd.Parameters.AddWithValue("@Message", Message);
                    try
                    {
                        SMScmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString(), "Error for 24 hour");
                    }
                }
            }
            //Console.WriteLine("Done!");
            //Console.ReadKey();
        }
    }
}
