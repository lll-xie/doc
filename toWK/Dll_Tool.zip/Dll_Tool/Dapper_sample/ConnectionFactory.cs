﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Data;
using Fujifilm.QB.Common;
using Dapper;
using Dapper.Contrib;

namespace Fujifilm.QB.Dal
{
    public class ConnectionFactory
    {
        public static IDbConnection GetOpenConnection()
        {
            var connection = new SqlConnection(ConfigurationManager.ConnectionStrings[Constant.CONNECTION_STRING_NAME].ConnectionString);

            connection.Open();

            return connection;
        }
    }
}
