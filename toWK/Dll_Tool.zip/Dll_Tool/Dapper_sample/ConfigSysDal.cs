﻿using Fujifilm.QB.Dal.Models;
using Fujifilm.QB.Dal.Repositorys;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fujifilm.QB.Dal
{
    public class ConfigSysDal:IDisposable
    {
        private readonly ConfigSysRepository sysConfigRepository = new ConfigSysRepository();

        public async Task<SysConfigModel> GetConfigByName(string name)
        {
            var sysConfig = await sysConfigRepository.GetConfigByName(name);
            if (sysConfig == null)
            {
                return null;
            }
            return new SysConfigModel
            {
                ID = sysConfig.ID,
                Name = sysConfig.Name,
                Value = sysConfig.Value,
                CreatedBy = sysConfig.CreatedBy,
                CreateTime = sysConfig.CreateTime,
                LastUpdatedBy = sysConfig.LastUpdatedBy,
                LastUpdateTime = sysConfig.LastUpdateTime
            };
        }

        public async Task<int> GetIntValueConfig(string name)
        {
            var config = await GetConfigByName(name);
            if (config == null)
                throw new Exception("未找到名为"+name+"的配置");
            return Convert.ToInt32(config.Value);
        }

        public async Task<IList<SysConfigModel>> ListSystemConfigs()
        {
            var result = await sysConfigRepository.ListSystemConfigs();
            var sysConfigs = new List<SysConfigModel>();
            var enumerator = result.GetEnumerator();
            while (enumerator.MoveNext())
            {
                var sysConfig = enumerator.Current;
                sysConfigs.Add(new SysConfigModel() {
                    ID = sysConfig.ID,
                    Value = sysConfig.Value,
                    Description = sysConfig.Description,
                    CreatedBy = sysConfig.CreatedBy,
                    CreateTime = sysConfig.CreateTime,
                    LastUpdatedBy = sysConfig.LastUpdatedBy,
                    LastUpdateTime = sysConfig.LastUpdateTime
                });
            }
            return sysConfigs;

        }

        public async Task<bool> UpdateSystemConfig(int id, string value)
        {
            return await sysConfigRepository.UpdateSystemConfig(id,value);
        }

        public static ConfigSysDal Create()
        {
            return new ConfigSysDal();
        }

        #region IDisposable Support
        private bool disposedValue = false; // 要检测冗余调用

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 释放托管状态(托管对象)。
                }

                // TODO: 释放未托管的资源(未托管的对象)并在以下内容中替代终结器。
                // TODO: 将大型字段设置为 null。

                disposedValue = true;
            }
        }

        // TODO: 仅当以上 Dispose(bool disposing) 拥有用于释放未托管资源的代码时才替代终结器。
        // ~ConfigSysDal() {
        //   // 请勿更改此代码。将清理代码放入以上 Dispose(bool disposing) 中。
        //   Dispose(false);
        // }

        // 添加此代码以正确实现可处置模式。
        public void Dispose()
        {
            // 请勿更改此代码。将清理代码放入以上 Dispose(bool disposing) 中。
            Dispose(true);
            // TODO: 如果在以上内容中替代了终结器，则取消注释以下行。
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
