﻿using Fujifilm.QB.Dal.Models;
using Fujifilm.QB.Dal.Repositorys;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fujifilm.QB.Dal
{
    public class MachineModeDal
    {
        private readonly MachineModeRepository machineModeRepository = new MachineModeRepository();

        public async Task<Tuple<bool, List<string>>> AddMachineModes(IList<MachineModeAddModel> machineModeModels, string createdBy)
        {
            return await machineModeRepository.AddMachineModes(machineModeModels, createdBy);
        }

        public async Task<IEnumerable<MachineModeModel>> SearchMachineModes(bool isFilterProductStyle, string id)
        {
            var result = await machineModeRepository.SearchMachineModes(isFilterProductStyle, id);
            var machineModes = new List<MachineModeModel>();
            foreach (var mode in result)
            {
                machineModes.Add(new MachineModeModel()
                {
                    ID = mode.ID,
                    Description = mode.Description,
                    CreatedBy = mode.CreatedBy,
                    CreateTime = mode.CreateTime,
                    LastUpdatedBy = mode.LastUpdatedBy,
                    LastUpdateTime = mode.LastUpdateTime
                });
            }
            return machineModes;
        }

        public async Task<Tuple<bool, string>> UpdateMachineMode(MachineModeModel machineModeModel, string userID)
        {
            if(machineModeModel.OldID == machineModeModel.ID)
            {
                var result = await machineModeRepository.UpdateMachineModeDescription(machineModeModel, userID);

                return result ? new Tuple<bool, string>(true, "更新机种描述成功。") : new Tuple<bool, string>(false, "更新机种描述失败，请联系管理员。");
            }
            else
            {
                var existsMachineModel = ExistMachineMode(machineModeModel.ID);
                if (existsMachineModel)
                {
                    return new Tuple<bool, string>(false, "该机种信息已存在！");
                }

                var result = await machineModeRepository.UpdateMachineMode(machineModeModel, userID);
                return result ? new Tuple<bool, string>(true, "更新机种成功。") : new Tuple<bool, string>(false, "更新机种失败，请联系管理员。");
            }
        }

        public async Task<bool> MachineModeHasProductStyle(string machineModeId)
        {
            var result = await machineModeRepository.MachineModeHasProductStyle(machineModeId);

            return result;
        }

        public async Task<bool> DeleteMachineMode(string id, string deletedBy)
        {
            var result = await machineModeRepository.DeleteMachineMode(id, deletedBy);

            return result;
        }

        public bool ExistMachineMode(string machineModeID,string description)
        {
            return machineModeRepository.ExistMachineMode(machineModeID, description);
        }

        public bool ExistMachineMode(string machineModeID)
        {
            return machineModeRepository.ExistMachineMode(machineModeID);
        }
    }
}
