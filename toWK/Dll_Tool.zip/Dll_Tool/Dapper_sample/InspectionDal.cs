﻿using Fujifilm.QB.Common;
using Fujifilm.QB.Dal.Models;
using Fujifilm.QB.Dal.Repositorys;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fujifilm.QB.Dal
{
    public class InspectionDal
    {
        private readonly InspectionRepository inspectionRepository = new InspectionRepository();

        public async Task<IEnumerable<SearchInspectionModel>> SearchInspection(SearchInspectionConditionModel searchInspectionConditionModel)
        {
            if (!searchInspectionConditionModel.IsTestMode)
            {
                var result = await inspectionRepository.SearchInspection(searchInspectionConditionModel);
                return result;
            }
            else
            {
                var result = await inspectionRepository.SearchTestInspection(searchInspectionConditionModel);
                return result;
            }
        }

        /// <summary>
        /// 分正常模式和测试模式
        /// 测试模式取测试表数据
        /// </summary>
        /// <param name="machineModeID"></param>
        /// <param name="productStyleID"></param>
        /// <param name="makeNumber"></param>
        /// <param name="shipNumber"></param>
        /// <param name="productType"></param>
        /// <param name="isTestMode"></param>
        /// <returns></returns>
        public async Task<UnderInspectionModel> SearchInspection(string machineModeID, string productStyleID, string makeNumber, string shipNumber, int productType, bool isTestMode)
        {
            return await inspectionRepository.SearchInspection(machineModeID, productStyleID, makeNumber, shipNumber, productType, isTestMode);
        }

        public async Task<bool> DeleteInspection(long id, string deletedBy, bool isTestMode = false)
        {
            var result = await inspectionRepository.DeleteInspection(id, deletedBy, isTestMode);

            return result;
        }

        public async Task<Tuple<bool, string, InspectionModel>> GetInspectionByID(long id, string userID, bool isTestMode = false,bool isViewMode = false)
        {
            var result = await inspectionRepository.GetInspectionByID(id, userID, isTestMode, isViewMode);
            return result;
        }

        public async Task<InspectionModel> GetInspectionByID(long id, long versionID, bool isTestMode = false)
        {
            var result = await inspectionRepository.GetInspectionByID(id, versionID, isTestMode);
            return result;
        }

        public async Task<Tuple<bool, ItemOperatorModel>> UpdateInspectionItemResult(InspectionItemResultModel inspectionItemResultModel, bool ngOperate = false, bool isTestMode = false)
        {
            return await inspectionRepository.UpdateInspectionItemResult(inspectionItemResultModel, ngOperate, isTestMode);
        }

        public async Task<bool> IsSequentialOperation(long inspectionItemID, bool isTestMode = false)
        {
            var result = await inspectionRepository.IsSequentialOperation(inspectionItemID, isTestMode);
            return result;
        }

        public async Task<Tuple<bool, string>> IsCriterionTypeNoCriterion(long inspectionItemID, bool isTestMode = false)
        {
            var result = await inspectionRepository.IsCriterionTypeNoCriterion(inspectionItemID, isTestMode);
            if (result.FinalResult != null)
            {
                return new Tuple<bool, string>(false, "检查项已做过判定操作,不可重复操作。");
            }
            else if (result.CriterionTypeID == Constant.NO_CRITERION_TYPE_ID)
            {
                return new Tuple<bool, string>(false, "检查项无判定基准,无需判定,请按作业顺序进行操作。 ");
            }
            return new Tuple<bool, string>(true, "");
        }

        public async Task<bool> StopInspection(long id, string userID, bool isTestMode = false)
        {
            var result = await inspectionRepository.StopInspection(id, userID, isTestMode);
            return result;
        }

        public async Task<Tuple<bool, string>> CreateNewInspection(CreateNewInspectionModel createNewInspection, string createdBy)
        {
            if (!createNewInspection.IsTestMode)
            {
                return await inspectionRepository.CreateNewInspection(createNewInspection, createdBy);
            }
            else
            {
                return await inspectionRepository.TestCreateNewInspection(createNewInspection, createdBy);
            }
        }

        public async Task<long> GetInspectionIDByItemID(long inspectionItemID, bool isTestMode = false)
        {
            return await inspectionRepository.GetInspectionIDByItemID(inspectionItemID, isTestMode);
        }

        public async Task<bool> SaveInspectionSublist(InspectionSubTableModel inspectionSubTableModel, string userID)
        {
            return await inspectionRepository.SaveInspectionSublist(inspectionSubTableModel.InspectionSublistModel, userID, inspectionSubTableModel.IsTestMode);
        }

        public async Task<Tuple<bool, string>> BrekOut(long inspectionID, string remarks, string createdBy, bool isTestMode = false)
        {
            return await inspectionRepository.BrekOut(inspectionID, remarks, createdBy, isTestMode);
        }

        public async Task<Tuple<bool, string>> ConfirmInspectionSelectItem(long inspectionItemID, string userID, bool isTestMode = false)
        {
            return await inspectionRepository.ConfirmInspectionSelectItem(inspectionItemID, userID, isTestMode);
        }

        public async Task<Tuple<bool,string>> IsInspectinItemAlreadySelected(long inspectionItemID, long inspectionID, bool isTestMode = false)
        {
            return await inspectionRepository.IsInspectinItemAlreadySelected(inspectionItemID, inspectionID, isTestMode);
        }

        public async Task<bool> CanNGOperate(long inspectionItemID, bool isTestMode = false)
        {
            return await inspectionRepository.CanNGOperate(inspectionItemID, isTestMode);
        }

        public async Task<Tuple<bool, string, InspectionConfirmorModel>> FinalConfirmation(long inspectionID, string userID, bool isTestMode = false)
        {
            return await inspectionRepository.FinalConfirmation(inspectionID, userID, isTestMode);
        }

        public async Task<bool> IsInspectionAlreadyConfirmed(long inspectionID, bool isTestMode = false)
        {
            return await inspectionRepository.IsInspectionAlreadyConfirmed(inspectionID, isTestMode);
        }

        public async Task<bool> CanStockOut(List<long> ids, bool isTestMode = false)
        {
            return await inspectionRepository.CanStockOut(ids, isTestMode);
        }

        public async Task<bool> StockOut(StockOutModel stockOuts, string createdBy)
        {
            return await inspectionRepository.StockOut(stockOuts, createdBy);
        }

        public async Task<int> GetInspectionStatusIDByItemID(long itemID, bool isTestMode = false)
        {
            return await inspectionRepository.GetInspectionStatusIDByItemID(itemID, isTestMode);
        }

        public async Task<bool> CanManualNA(long inspectionID, bool isTestMode = false)
        {
            return await inspectionRepository.CanManualNA(inspectionID, isTestMode);
        }

        public async Task<bool> ManulaNA(long inspectionID, string remarks, string createdBy, bool isTestMode = false)
        {
            return await inspectionRepository.ManulaNA(inspectionID, remarks, createdBy, isTestMode);
        }

        public async Task<bool> Repair(StockOutModel reworkItems, string createdBy)
        {
            return await inspectionRepository.Repair(reworkItems, createdBy);
        }

        public async Task<bool> CanRework(long inspectionItemID)
        {
            return await inspectionRepository.CanRework(inspectionItemID);
        }

        public async Task<IEnumerable<TemplateInspectionGroupModel>> SearchInspectionGroup(string machineModeID, string productStyleID, string inspectionGroupName)
        {
            var result = await inspectionRepository.SearchInspectionGroup(machineModeID, productStyleID, inspectionGroupName);
            return result;
        }

        public async Task<bool> AddInspectionGroup(TemplateInspectionGroupModel templateInspectionGroupModel, string userID)
        {
            var result = await inspectionRepository.AddInspectionGroup(templateInspectionGroupModel, userID);
            return result;
        }

        public async Task<bool> OpenCloseInspectionGroup(long id, bool openOrClose, string userID)
        {
            var result = await inspectionRepository.OpenCloseInspectionGroup(id, openOrClose, userID);
            return result;
        }

        public async Task<Tuple<bool, string>> IsInspectionGroupAlreadyExists(TemplateInspectionGroupModel templateInspectionGroupModel)
        {
            var result = await inspectionRepository.IsInspectionGroupAlreadyExists(templateInspectionGroupModel);
            return result;
        }

        public async Task<IEnumerable<SearchInspectionModel>> SearchAvailableComponentInspection(string machineModeID, string productStyleID, string productNumber, bool isTestMode = false)
        {
            if (!isTestMode)
            {
                var result = await inspectionRepository.SearchAvailableComponentInspection(machineModeID, productStyleID, productNumber);
                return result;
            }
            else
            {
                var result = await inspectionRepository.TestSearchAvailableComponentInspection(machineModeID, productStyleID, productNumber);
                return result;
            }
        }

        public async Task<Tuple<bool, string>> MergeComponentInspection(MergedComponentListModel mergedComponentListModel, string userID)
        {
            var result = await inspectionRepository.MergeComponentInspection(mergedComponentListModel.SearchInspectionModels, userID, mergedComponentListModel.IsTestMode);
            return result;
        }

        public async Task<bool> RemoveComponentInspection(long id, string userID, bool isTestMode = false)
        {
            var result = await inspectionRepository.RemoveComponentInspection(id, userID, isTestMode);
            return result;
        }

        public async Task<List<ConfigInspectionStatusModel>> GetInspectionStatus()
        {
            var result = await inspectionRepository.GetInspectionStatus();
            var inspectionStatus = new List<ConfigInspectionStatusModel>();
            foreach (var status in result)
            {
                inspectionStatus.Add(new ConfigInspectionStatusModel()
                {
                    ID = status.ID,
                    DisplayName = status.DisplayName
                });
            }
            return inspectionStatus;
        }

        public async Task<IEnumerable<InspectionVersionModel>> GetInspectionVersionByID(long inspectionID, bool isTestMode = false)
        {
            var result = await inspectionRepository.GetInspectionVersionByID(inspectionID, isTestMode);
            return result;
        }

        public async Task<bool> CanEditInspection(long id)
        {
            return await inspectionRepository.CanEditInspection(id);
        }

        public async Task<bool> CanCreateInspection(long templateInspectionID, string productNumber)
        {
            return await inspectionRepository.CanCreateInspection(templateInspectionID, productNumber);
        }

        public async Task<IEnumerable<InspectionItemModel>> GetFirstVersionWMItems(long id, bool isTestMode = false)
        {
            return await inspectionRepository.GetFirstVersionWMItems(id, isTestMode);
        }

        public async Task<Tuple<bool, string, List<TxtExtractTemplateInspectionModel>>> ExtractTXTInspection(string machineModeID, string productNumberStart, string userID, bool isTestMode = false)
        {
            return await inspectionRepository.ExtractTxtInspection(machineModeID, productNumberStart, userID, isTestMode);
        }

        public bool IsMachineModeAndProductStyleUsedByInspection(string machineModeId, string productStyleId)
        {
            return inspectionRepository.IsMachineModeAndProductStyleUsedByInspection(machineModeId, productStyleId);
        }

        public async Task<bool> IsTxtTemplateInspection(long templateInspectionId)
        {
            return await inspectionRepository.IsTxtTemplateInspection(templateInspectionId);
        }

        public async Task<IEnumerable<TxtInspectionModel>> SearchTXTInspection(string machineModeID, string productNo,bool isTestMode = false)
        {
            return await inspectionRepository.SearchTXTInspection(machineModeID, productNo,isTestMode);
        }

        public async Task<bool> UnlockTXTInspection(long inspectionId,string userID,bool isTestMode = false)
        {
            return await inspectionRepository.UnlockTXTInspection(inspectionId, userID, isTestMode);
        }
    }
}
