﻿namespace Fujifilm.QB.Dal
{
    public class LatestInspectionModel
    {
        public long InspectionGroupID { get; set; }
        public int ProcessSequence { get; set; }
        public long InspectionTypeGroupID { get; set; }
    }
}
