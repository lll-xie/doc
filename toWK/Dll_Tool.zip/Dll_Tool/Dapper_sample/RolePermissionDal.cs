﻿using Fujifilm.QB.Dal.Models;
using Fujifilm.QB.Dal.Repositorys;
using Fujifilm.QB.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fujifilm.QB.Dal
{
    public class RolePermissionDal : IDisposable
    {
        private readonly RolePermissionRepository rolePermissionRepository = new RolePermissionRepository();
        private readonly LoginModeRepository loginModeRepository = new LoginModeRepository();

        public async Task<IEnumerable<PermissionModel>> GetPermissions()
        {
            var result = await rolePermissionRepository.GetAll();

            var permissions = new List<PermissionModel>();

            if(result.Count() > 0)
            {
                var enumerator = result.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var role = enumerator.Current;
                    permissions.Add(new PermissionModel()
                    {
                        ID = role.ID,
                        Name = role.Name
                    });
                }
            }

            return permissions;
        }

        public async Task<Tuple<List<PermissionModel>, List<LoginModeModel>>> GetPermissionsAndModes()
        {
            var loginModes = await loginModeRepository.GetAll();
            var permissions = await rolePermissionRepository.GetAll();

            var loginModeList = new List<LoginModeModel>();
            var permissionList = new List<PermissionModel>();

            if (permissions.Count() > 0)
            {
                var enumerator = permissions.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var role = enumerator.Current;
                    permissionList.Add(new PermissionModel()
                    {
                        ID = role.ID,
                        Name = role.Name
                    });
                }
            }

            if (loginModes.Count() > 0)
            {
                var enumerator = loginModes.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var mode = enumerator.Current;
                    loginModeList.Add(new LoginModeModel()
                    {
                        ID = mode.ID,
                        Name = mode.Name
                    });
                }
            }

            return Tuple.Create(permissionList, loginModeList);
        }

        public async Task<List<LoginModeModel>> GetLoginModes()
        {
            var loginModes = await loginModeRepository.GetAll();
            var loginModeList = new List<LoginModeModel>();

            if (loginModes.Count() > 0)
            {
                var enumerator = loginModes.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var mode = enumerator.Current;
                    loginModeList.Add(new LoginModeModel()
                    {
                        ID = mode.ID,
                        Name = mode.Name
                    });
                }
            }

            return loginModeList;
        }

        public async Task<Tuple<List<RolePermissionModel>, List<RoleModeModel>>> GetRolePermissionByRoleID(long roleID)
        {
            var rolePermissionsModels = await rolePermissionRepository.GetRolePermissionByRoleID(roleID);
            var roleModeModels = await rolePermissionRepository.GetRoleModeByRoleID(roleID);

            var rolePermissions = new List<RolePermissionModel>();
            var roleModes = new List<RoleModeModel>();

            if(rolePermissionsModels.Count() > 0)
            {
                var enumerator = rolePermissionsModels.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var rolePermission = enumerator.Current;
                    rolePermissions.Add(new RolePermissionModel()
                    {
                        RoleID = rolePermission.RoleID,
                        PermissionID = rolePermission.PermissionID
                    });
                }
            }
            if (roleModeModels.Count() > 0)
            {
                var enumerator = roleModeModels.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var roleMode = enumerator.Current;
                    roleModes.Add(new RoleModeModel()
                    {
                        RoleID = roleMode.RoleID,
                        LoginModeID = roleMode.LoginModeID
                    });
                }
            }

            return Tuple.Create(rolePermissions, roleModes);
        }

        public async Task<Tuple<bool, string>> UpdateRolePermission(RoleModePermissionUpdateModel roleModePermissionUpdateModel, string createdBy)
        {
            var result = await rolePermissionRepository.UpdateRolePermission(roleModePermissionUpdateModel.RoleID, roleModePermissionUpdateModel.PermisionIDs, roleModePermissionUpdateModel.ModeIDs, createdBy);

            if (result)
            {
                return new Tuple<bool, string>(true, null);
            }
            return new Tuple<bool, string>(false, "修改角色权限失败。");
        }

        public async Task<Tuple<bool, string>> AddRolePermission(RolePermissionAddModel rolePermissionAddModel,string createdBy)
        {
            var roleName = rolePermissionAddModel.RoleName;

            var rolePermissionIDs = new List<long>();
            var roleModeIDs = new List<int>();

            foreach(var permission in rolePermissionAddModel.PermissionModels)
            {
                rolePermissionIDs.Add(permission.ID);
            }
            foreach (var mode in rolePermissionAddModel.LoginModeModels)
            {
                roleModeIDs.Add(mode.ID);
            }

            return await rolePermissionRepository.AddRolePermission(roleName, rolePermissionIDs, roleModeIDs, createdBy);
        }

        public async Task<List<LoginModePermissionModel>> GetLoginModePermissions()
        {
            var loginModePermissions = new List<LoginModePermissionModel>();

            var result = await loginModeRepository.GetLoginModePermissions();

            if (result.Count() > 0)
            {
                var enumerator = result.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var loginModePermission = enumerator.Current;
                    loginModePermissions.Add(new LoginModePermissionModel()
                    {
                        LoginModeID = loginModePermission.LoginModeID,
                        PermissionID = loginModePermission.PermissionID
                    });
                }
            }
            return loginModePermissions;
        }
        #region IDisposable Support
        private bool disposedValue = false; // 要检测冗余调用

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 释放托管状态(托管对象)。
                }

                // TODO: 释放未托管的资源(未托管的对象)并在以下内容中替代终结器。
                // TODO: 将大型字段设置为 null。

                disposedValue = true;
            }
        }

        // TODO: 仅当以上 Dispose(bool disposing) 拥有用于释放未托管资源的代码时才替代终结器。
        // ~RoleDal() {
        //   // 请勿更改此代码。将清理代码放入以上 Dispose(bool disposing) 中。
        //   Dispose(false);
        // }

        // 添加此代码以正确实现可处置模式。
        public void Dispose()
        {
            // 请勿更改此代码。将清理代码放入以上 Dispose(bool disposing) 中。
            Dispose(true);
            // TODO: 如果在以上内容中替代了终结器，则取消注释以下行。
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
