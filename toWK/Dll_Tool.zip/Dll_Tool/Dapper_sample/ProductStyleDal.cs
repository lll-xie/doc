﻿using Fujifilm.QB.Dal.Models;
using Fujifilm.QB.Dal.Repositorys;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fujifilm.QB.Dal
{
    public class ProductStyleDal
    {
        private readonly ProductStyleRepository productStyleRepository = new ProductStyleRepository();

        public async Task<IEnumerable<ProductStyleModel>> SearchProductStyle(string machineModeID, string productStyleID)
        {
            var result = await productStyleRepository.SearchProductStyle(machineModeID, productStyleID);
            var productStyleList = new List<ProductStyleModel>();
            foreach (var productStyle in result)
            {
                productStyleList.Add(new ProductStyleModel()
                {
                    ID = productStyle.ID,
                    MachineModeID = productStyle.MachineModeID,
                    Description = productStyle.Description,
                    CreatedBy = productStyle.CreatedBy,
                    CreateTime = productStyle.CreateTime,
                    LastUpdatedBy = productStyle.LastUpdatedBy,
                    LastUpdateTime = productStyle.LastUpdateTime
                });
            }
            return productStyleList;
        }

        public async Task<Tuple<bool, List<string>>> AddProductStyle(ProductStyleAddModel productStyle, string createdBy)
        {
            return await productStyleRepository.AddProductStyle(productStyle, createdBy);
        }

        public async Task<Tuple<bool, string>> UpdateProductStyle(ProductStyleModel productStyleModel, string userID)
        {
            if(productStyleModel.OldID == productStyleModel.ID)
            {
                var result = await productStyleRepository.UpdateProductStyleDescription(productStyleModel, userID);
                return result ? new Tuple<bool, string>(true, "更新式样描述成功。") : new Tuple<bool, string>(false, "更新式样描述失败，请联系管理员。");
            }
            else
            {
                var existsMachineModel = ExistProductStyle(productStyleModel.ID, productStyleModel.MachineModeID);
                if (existsMachineModel)
                {
                    return new Tuple<bool, string>(false, "该机种下已存在该式样！");
                }

                var result = await productStyleRepository.UpdateProductStyle(productStyleModel, userID);
                return result ? new Tuple<bool, string>(true, "更新式样成功。") : new Tuple<bool, string>(false, "更新式样失败，请联系管理员。");
            }
        }

        public async Task<bool> DeleteProductStyle(string machineModeID, string productStyleID, string deletedBy)
        {
            var result = await productStyleRepository.DeleteProductStyle(machineModeID, productStyleID, deletedBy);

            return result;
        }

        public bool ExitProductStyle(string productStyleID)
        {
            return productStyleRepository.ExitProductStyle(productStyleID);
        }

        public bool ExistProductStyle(string productStyleID, string machineModeID)
        {
            return productStyleRepository.ExitProductStyle(productStyleID, machineModeID);
        }

        public async Task<IEnumerable<ProductStyleModel>> GetProductStyle(string machineModeID)
        {
            var result = await productStyleRepository.GetProductStyle(machineModeID);
            var productStyleList = new List<ProductStyleModel>();
            foreach (var productStyle in result)
            {
                productStyleList.Add(new ProductStyleModel()
                {
                    ID = productStyle.ID,
                    MachineModeID = productStyle.MachineModeID,
                    Description = productStyle.Description,
                    CreatedBy = productStyle.CreatedBy,
                    CreateTime = productStyle.CreateTime,
                    LastUpdatedBy = productStyle.LastUpdatedBy,
                    LastUpdateTime = productStyle.LastUpdateTime
                });
            }
            return productStyleList;
        }

        public bool HasProductStyleByMachineModeId(string machineModeID)
        {
            return productStyleRepository.HasProductStyleByMachineModeId(machineModeID);
        }

        public async Task<bool> ProductStyleUsedByInspection(string machineModeId, string productStyleId)
        {
            return await productStyleRepository.ProductStyleUsedByInspection(machineModeId, productStyleId);
        }

        public async Task<bool> ProductStyleUsedByTemplateInspection(string machineModeId, string productStyleId)
        {
            return await productStyleRepository.ProductStyleUsedByTemplateInspection(machineModeId, productStyleId);
        }
    }
}
