﻿using Fujifilm.QB.Dal.Models;
using Fujifilm.QB.Dal.Repositorys;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fujifilm.QB.Dal
{
    public class ConfigsDal
    {
        private readonly ConfigsRepository configsRepository = new ConfigsRepository();

        public async Task<IEnumerable<ConfigModel>> GetCriterionTypes()
        {
            var result = await configsRepository.GetCriterionTypes();
            var criterionTypes = new List<ConfigModel>();
            foreach (var criterionType in result)
            {
                criterionTypes.Add(new ConfigModel()
                {
                    ID = criterionType.ID,
                    DisplayName = criterionType.DisplayName
                });
            }
            return criterionTypes;
        }

        public async Task<IEnumerable<ConfigModel>> GetResultTypes()
        {
            var result = await configsRepository.GetResultTypes();
            var resultTypes = new List<ConfigModel>();
            foreach (var resultType in result)
            {
                resultTypes.Add(new ConfigModel()
                {
                    ID = resultType.ID,
                    DisplayName = resultType.DisplayName
                });
            }
            return resultTypes;
        }
    }
}
