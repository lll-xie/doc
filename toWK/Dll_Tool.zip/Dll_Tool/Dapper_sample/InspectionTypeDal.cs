﻿using Fujifilm.QB.Dal.Models;
using Fujifilm.QB.Dal.Repositorys;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fujifilm.QB.Dal
{
    public class InspectionTypeDal
    {
        private static readonly InspectionTypeRepository inspectionTypeRepository = new InspectionTypeRepository();

        public async Task<IEnumerable<InspectionTypeModel>> SearchInspectionTypes(string inspectionName, string groupName)
        {
            return await inspectionTypeRepository.SearchInspectionTypes(inspectionName, groupName);
        }

        public bool ExistInspectionGroup(string groupName)
        {
            return inspectionTypeRepository.ExistInspectionGroup(groupName);
        }

        public async Task<bool> AddInspectionTypes(InspectionTypeAddModel inspectionTypes, string createdBy)
        {
            return await inspectionTypeRepository.AddInspectionTypes(inspectionTypes, createdBy);
        }

        public async Task<Tuple<bool, string>> UpdateInspectionType(InspectionTypeModel inspectionTypeModel, string userID)
        {
            var result = await inspectionTypeRepository.UpdateInspectionType(inspectionTypeModel, userID);

            if (result)
            {
                return new Tuple<bool, string>(true, "更新工程成功。");
            }
            else
            {
                return new Tuple<bool, string>(false, "更新工程失败，请联系管理员。");
            }
        }

        public async Task<List<InspectionTypeGroupModel>> GetInspectionTypeGroups()
        {
            var result = await inspectionTypeRepository.GetInspectionTypeGroups();
            var inspectionTypeGroups = new List<InspectionTypeGroupModel>();
            foreach (var group in result)
            {
                inspectionTypeGroups.Add(new InspectionTypeGroupModel()
                {
                    ID = group.ID,
                    Name = group.Name
                });
            }
            return inspectionTypeGroups;
        }

        public async Task<int> GetInspectionTypeGroup(int inspectionTypeID)
        {
            return await inspectionTypeRepository.GetInspectionTypeGroup(inspectionTypeID);
        }

        public async Task<IEnumerable<InspectionTypeBindingModel>> GetInspectionTypes(string groupName)
        {
            return await inspectionTypeRepository.GetInspectionTypes(groupName);
        }

        public bool IsInspectionTypeDisplayNameIsDeputyGroup(int inspectionTypeID)
        {
            return inspectionTypeRepository.IsInspectionTypeDisplayNameIsDeputyGroup(inspectionTypeID);
        }
    }
}
